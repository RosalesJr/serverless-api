// third party library
const dynamoose = require('dynamoose');
// to be continued (code locally, zip, and upload)

// create a schema
const peopleSchema = new dynamoose.Schema({
    id: Number,
    name: String,
    state: String,
});

// create a model
const peopleModel = dynamoose.model('friends-demo', peopleSchema);

exports.handler = async (event) => {
    console.log('asdgasfh-----', event.body)

    // pkan A extract from the body
    let parsedBody = JSON.parse(event.body);
    let { id, name, phone} = parsedBody;

    // plan B if cannot extract from the body
    // let { id, name, phone} = event.queryStringParameters;

    let people = {id, name, state}
    console.log(people);

    const response = {statusCode: null, body: null};

    try {
        let newPerson = await peopleModel.create(people);
        response.statusCode = 200;
        response.body = JSON.stringify(newPerson);

    } catch (e) {
        console.log(e);
        response.statusCode = 500;
        response.body = JSON.stringify(e.message);
    }


    return response;
};